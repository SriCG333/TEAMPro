package tests;

import browsers.BrowserHandler;
import jxl.Sheet;
import jxl.Workbook;
import jxl.read.biff.BiffException;
import pages.SwagPages;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;



public class SwagTests {
    private WebDriver driver;
    private SwagPages swagPages;
	 Workbook wb;
		Sheet sh;
		Integer row;
		String userName,password;

		  public void generateScreenshots(String path) throws IOException {
			  TakesScreenshot ts = (TakesScreenshot) driver;
			  File fl = ts.getScreenshotAs(OutputType.FILE);
			  FileUtils.copyFile(fl, new File(path));
		 }
		
    @Test()
    public void setup() {
    	
        driver = BrowserHandler.initializeBrowser();
        swagPages = new SwagPages(driver);
        swagPages.navigateToLoginPage();
    }

    @Test(dependsOnMethods = "FailLoginTest")
    public void LoginTest() {
        swagPages.login("standard_user", "secret_sauce");
    }

    @Test(dependsOnMethods = "LoginTest" )
    public void ImagesIsDisplaying() throws IOException {
    	swagPages.Displaying();
    	
    }
//////////////////////////////
    @Test(dependsOnMethods = "ResourcesHoveOver")
      public void LogoutTest() {
        //swagPages.login("standard_user", "secret_sauce");
        swagPages.logout();
//////////////////////////////
     }
       @Test(dependsOnMethods = "MultipleLogin")
        public void FailLoginTest() throws IOException {
    	   swagPages.login("locked_out_user", "secret_sauce");
    	   swagPages.FailLogin();
      }
    
	  @Test(dataProvider = "TestData",dependsOnMethods = "LogoTest")
		public void MultipleLogin(String uName,String pwd) {
		  swagPages.login(uName, pwd);
		  swagPages.logout();
	  }
    
        @DataProvider(name = "TestData")
        public Object[][] LogTestData() throws BiffException, IOException {
          wb = Workbook.getWorkbook(new File("C:\\Users\\basil.b\\OneDrive - HCL TECHNOLOGIES LIMITED\\Desktop\\BASIL\\PROJECT BRRRRRR\\DATA Provider.xls")); //Replace with your path
          sh = wb.getSheet(0);
          row = sh.getRows();
        Object[][] SwagData = new Object[row][sh.getColumns()];
  		for (int i = 0 ;i<row;i++) {
  			SwagData[i][0] = sh.getCell(0,i).getContents();
  			SwagData[i][1] = sh.getCell(1,i).getContents();
      }
        return SwagData;
      }

    	@Test(dependsOnMethods = "setup")
    	 public void SoftAssertTitle() {
    		swagPages.Title();
      }
    
	  @Test(dependsOnMethods = "SoftAssertTitle" )
	     public void LogoTest() throws IOException {
	    	 swagPages.Logo();	    	 
	  }
	  
	  @Test(dependsOnMethods = "ImagesIsDisplaying" )
	     public void ImageInteraction() throws IOException {
		  swagPages.Interaction();
	  }
	  
	  @Test(dependsOnMethods = "ImageInteraction" )
	     public void AddingRemovingThings() throws IOException{
		  swagPages.AddingAndRemoving();
	  }
	  
	  @Test(dependsOnMethods = "AddingRemovingThings" )
	  	public void Filter() throws IOException{
		  swagPages.Filter();
	  }
	     
	  @Test(dependsOnMethods = "Filter")
	     public void AddingRemovingFromCart() throws IOException {
		  swagPages.AddingAndRemovingCart();
	  }
	  
	  @Test(dependsOnMethods = "AddingRemovingFromCart")
	     public void Errorhandler1() throws IOException {
		  swagPages.ErrorHanler1();
	  }
	  
	  @Test(dependsOnMethods = "Errorhandler1")
	     public void Errorhandler2() throws IOException {
		  swagPages.ErrorHanler2("Adithya");
	  }
	  
	  @Test(dependsOnMethods = "Errorhandler2")
	     public void Errorhandler3() throws IOException {
		  swagPages.ErrorHanler3("Adithya","Namayan");
	  }
	  
	  @Test(dependsOnMethods = "Errorhandler3")
	     public void ShoppingTime() throws IOException {
		  swagPages.ShoppingTime("Adithya","Namayan","6969420");
	  }
	  
	  @Test(dependsOnMethods = "ShoppingTime")
	     public void About() throws IOException{
		  swagPages.About();
	  }
	  
	  @Test(dependsOnMethods = "About")
	     public void HoveOver() throws IOException{
		  swagPages.Hover();
	  }
	  
	  @Test(dependsOnMethods = "HoveOver")
	     public void HoveOver2() throws IOException{
		  swagPages.Hover2();
	  }	  
	  
	  @Test(dependsOnMethods = "HoveOver2")
	     public void ButtonHoveOver() throws IOException{
		  swagPages.BHover();
	  }	 
	  
	  @Test(dependsOnMethods = "ButtonHoveOver")
	     public void ProductsHoveOver() throws IOException{
		  swagPages.Products();
	  }	
	  
	  @Test(dependsOnMethods = "ProductsHoveOver")
	     public void SolutionsHoveOver() throws IOException{
		  swagPages.Solutions();
	  }	  	
	  
	  @Test(dependsOnMethods = "SolutionsHoveOver")
	     public void DevelopersHoveOver() throws IOException{
		  swagPages.Developers();
	  }	  
	  
	  @Test(dependsOnMethods = "DevelopersHoveOver")
	     public void ResourcesHoveOver() throws IOException{
		  swagPages.Resources();
	  }	  	
	  
	  @Test(dependsOnMethods = "LogoutTest")
    	public void tearDown() {
         BrowserHandler.closeBrowser();
    }
}