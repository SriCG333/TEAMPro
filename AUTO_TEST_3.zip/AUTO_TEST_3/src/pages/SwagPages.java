package pages;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.asserts.SoftAssert;

public class SwagPages {
     WebDriver driver;

	  public void generateScreenshots(String path) throws IOException {
		  TakesScreenshot ts = (TakesScreenshot) driver;
		  File fl = ts.getScreenshotAs(OutputType.FILE);
		  FileUtils.copyFile(fl, new File(path));
	 }
	  
     
    public SwagPages(WebDriver driver) {
        this.driver = driver;
    }

    public void navigateToLoginPage() {
        driver.get("https://www.saucedemo.com/v1/index.html");
    }

    public void login(String username, String password) {
        driver.findElement(By.name("user-name")).sendKeys(username);
        driver.findElement(By.name("password")).sendKeys(password);
        driver.findElement(By.cssSelector("#login-button")).click();
    }

    public void openMenu() {
        driver.findElement(By.cssSelector("#menu_button_container > div > div:nth-child(3) > div > button")).click();
    }

    public void Allitems() {
    	driver.findElement(By.cssSelector("#inventory_sidebar_link")).click();
    }
    
    public void logout() {
    	driver.navigate().refresh();
        openMenu();
        driver.findElement(By.cssSelector("#logout_sidebar_link")).click();
    }
    
    public void Title() {
        String Expected = "Swag Labs";
        String Actual = driver.getTitle();
        SoftAssert sa = new SoftAssert();
  	  sa.assertEquals(Actual, Expected);
        System.out.println("Soft assert test");
        System.out.println("Expected: "+Expected);
        System.out.println("Actual: "+Actual+"\n");
        sa.assertAll();
    }
    
    public void FailLogin() throws IOException {
    	//swagPages.login("locked_out_user", "secret_sauce");
    	generateScreenshots("C:\\Users\\basil.b\\OneDrive - HCL TECHNOLOGIES LIMITED\\Desktop\\Screenshots-SwagLabs\\FailLogin.jpg"); //Replace with your path
    	String Expected = "Epic sadface: Sorry, this user has been locked out.";
	      String Actual = driver.findElement(By.cssSelector("#login_button_container > div > form > h3")).getText();
	      SoftAssert sa = new SoftAssert();
		  sa.assertEquals(Actual, Expected);
	      System.out.println("Soft assert test");
	      System.out.println("Expected: "+Expected);
	      System.out.println("Actual: "+Actual+"\n");
	      sa.assertAll();	 
	      driver.navigate().refresh();
    }
    
    public void Logo() throws IOException {
    	generateScreenshots("C:\\Users\\basil.b\\OneDrive - HCL TECHNOLOGIES LIMITED\\Desktop\\Screenshots-SwagLabs\\StartPage.jpg"); //Replace with your path
    	driver.findElement(By.cssSelector("body > div.login_wrapper > div.login_wrapper-inner > img")).isDisplayed();
    	System.out.println("Logo is being displayed"+"\n");
    }
    
    public void Displaying() throws IOException {
    	generateScreenshots("C:\\Users\\basil.b\\OneDrive - HCL TECHNOLOGIES LIMITED\\Desktop\\Screenshots-SwagLabs\\HomePage.jpg"); //Replace with your path
        driver.findElement(By.cssSelector("#item_0_img_link > img")).isDisplayed();
        driver.findElement(By.cssSelector("#item_1_img_link > img")).isDisplayed();
        driver.findElement(By.cssSelector("#item_2_img_link > img")).isDisplayed();
        driver.findElement(By.cssSelector("#item_3_img_link > img")).isDisplayed();
        driver.findElement(By.cssSelector("#item_4_img_link > img")).isDisplayed();
        driver.findElement(By.cssSelector("#item_5_img_link > img")).isDisplayed();
        System.out.println("Images are displaying"+"\n");
    }
    
    public void Interaction() throws IOException {
        driver.findElement(By.cssSelector("#item_0_img_link > img")).click();
        generateScreenshots("C:\\Users\\basil.b\\OneDrive - HCL TECHNOLOGIES LIMITED\\Desktop\\Screenshots-SwagLabs\\ImageInteraction1.jpg"); //Replace with your path
        
        String Expected = "Sauce Labs Bike Light";
        String Actual = driver.findElement(By.xpath("//*[@id=\"inventory_item_container\"]/div/div/div/div[1]")).getText();
        SoftAssert sa = new SoftAssert();
  	  	sa.assertEquals(Actual, Expected);
        System.out.println("Soft assert test");
        System.out.println("Expected: "+Expected);
        System.out.println("Actual: "+Actual+"\n");
        sa.assertAll();
        
        driver.findElement(By.cssSelector("#inventory_item_container > div > button")).click();   
        driver.findElement(By.cssSelector("#item_1_img_link > img")).click();
        generateScreenshots("C:\\Users\\basil.b\\OneDrive - HCL TECHNOLOGIES LIMITED\\Desktop\\Screenshots-SwagLabs\\ImageInteraction2.jpg"); //Replace with your path
        
      String Expected1 = "Sauce Labs Bolt T-Shirt";
      String Actual1 = driver.findElement(By.xpath("//*[@id=\"inventory_item_container\"]/div/div/div/div[1]")).getText();
      SoftAssert sa1 = new SoftAssert();
	  	sa1.assertEquals(Actual1, Expected1);
      System.out.println("Soft assert test");
      System.out.println("Expected: "+Expected1);
      System.out.println("Actual: "+Actual1+"\n");
      sa1.assertAll();
        
        driver.findElement(By.cssSelector("#inventory_item_container > div > button")).click();
        driver.findElement(By.cssSelector("#item_2_img_link > img")).click();
        generateScreenshots("C:\\Users\\basil.b\\OneDrive - HCL TECHNOLOGIES LIMITED\\Desktop\\Screenshots-SwagLabs\\ImageInteraction3.jpg"); //Replace with your path
        
      String Expected2 = "Sauce Labs Onesie";
      String Actual2 = driver.findElement(By.xpath("//*[@id=\"inventory_item_container\"]/div/div/div/div[1]")).getText();
      SoftAssert sa2 = new SoftAssert();
	  	sa2.assertEquals(Actual2, Expected2);
      System.out.println("Soft assert test");
      System.out.println("Expected: "+Expected2);
      System.out.println("Actual: "+Actual2+"\n");
      sa2.assertAll();
        
        driver.findElement(By.cssSelector("#inventory_item_container > div > button")).click();
        driver.findElement(By.cssSelector("#item_3_img_link > img")).click();
        generateScreenshots("C:\\Users\\basil.b\\OneDrive - HCL TECHNOLOGIES LIMITED\\Desktop\\Screenshots-SwagLabs\\ImageInteraction4.jpg"); //Replace with your path
       
      String Expected3 = "Test.allTheThings() T-Shirt (Red)";
      String Actual3 = driver.findElement(By.xpath("//*[@id=\"inventory_item_container\"]/div/div/div/div[1]")).getText();
      SoftAssert sa3 = new SoftAssert();
	  	sa3.assertEquals(Actual, Expected);
      System.out.println("Soft assert test");
      System.out.println("Expected: "+Expected3);
      System.out.println("Actual: "+Actual3+"\n");
      sa3.assertAll();
        
        driver.findElement(By.cssSelector("#inventory_item_container > div > button")).click();
        driver.findElement(By.cssSelector("#item_4_img_link > img")).click();
        generateScreenshots("C:\\Users\\basil.b\\OneDrive - HCL TECHNOLOGIES LIMITED\\Desktop\\Screenshots-SwagLabs\\ImageInteraction5.jpg"); //Replace with your path
        
      String Expected4 = "Sauce Labs Backpack";
      String Actual4 = driver.findElement(By.xpath("//*[@id=\"inventory_item_container\"]/div/div/div/div[1]")).getText();
      SoftAssert sa4 = new SoftAssert();
	  	sa4.assertEquals(Actual, Expected);
      System.out.println("Soft assert test");
      System.out.println("Expected4: "+Expected4);
      System.out.println("Actual4: "+Actual4+"\n");
      sa4.assertAll();
        
        driver.findElement(By.cssSelector("#inventory_item_container > div > button")).click();
        driver.findElement(By.cssSelector("#item_5_img_link > img")).click();
        generateScreenshots("C:\\Users\\basil.b\\OneDrive - HCL TECHNOLOGIES LIMITED\\Desktop\\Screenshots-SwagLabs\\ImageInteraction6.jpg"); //Replace with your path
        
      String Expected5 = "Sauce Labs Fleece Jacket";
      String Actual5 = driver.findElement(By.xpath("//*[@id=\"inventory_item_container\"]/div/div/div/div[1]")).getText();
      SoftAssert sa5 = new SoftAssert();
	  	sa5.assertEquals(Actual5, Expected5);
      System.out.println("Soft assert test");
      System.out.println("Expected: "+Expected5);
      System.out.println("Actual: "+Actual5+"\n");
      sa5.assertAll();
        
        driver.findElement(By.cssSelector("#inventory_item_container > div > button")).click();
        //System.out.println("Yes images are interactable"+"\n");
    }
    
   public void AddingAndRemoving() throws IOException {
	   driver.findElement(By.cssSelector("#inventory_container > div > div:nth-child(1) > div.pricebar > button")).click();
       driver.findElement(By.cssSelector("#inventory_container > div > div:nth-child(2) > div.pricebar > button")).click();
       driver.findElement(By.cssSelector("#inventory_container > div > div:nth-child(3) > div.pricebar > button")).click();
       driver.findElement(By.cssSelector("#inventory_container > div > div:nth-child(4) > div.pricebar > button")).click();
       driver.findElement(By.cssSelector("#inventory_container > div > div:nth-child(5) > div.pricebar > button")).click();
       driver.findElement(By.cssSelector("#inventory_container > div > div:nth-child(6) > div.pricebar > button")).click();
       generateScreenshots("C:\\Users\\basil.b\\OneDrive - HCL TECHNOLOGIES LIMITED\\Desktop\\Screenshots-SwagLabs\\AddedToCart.jpg"); //Replace with your path
       driver.findElement(By.cssSelector("#inventory_container > div > div:nth-child(1) > div.pricebar > button")).click();
       driver.findElement(By.cssSelector("#inventory_container > div > div:nth-child(2) > div.pricebar > button")).click();
       driver.findElement(By.cssSelector("#inventory_container > div > div:nth-child(3) > div.pricebar > button")).click();
       driver.findElement(By.cssSelector("#inventory_container > div > div:nth-child(4) > div.pricebar > button")).click();
       driver.findElement(By.cssSelector("#inventory_container > div > div:nth-child(5) > div.pricebar > button")).click();
       driver.findElement(By.cssSelector("#inventory_container > div > div:nth-child(6) > div.pricebar > button")).click();
       generateScreenshots("C:\\Users\\basil.b\\OneDrive - HCL TECHNOLOGIES LIMITED\\Desktop\\Screenshots-SwagLabs\\RemovedFromCart.jpg"); //Replace with your path
       //System.out.println("Yes able to add and remove"+"\n");
   }

   public void Filter() throws IOException {
	   driver.findElement(By.cssSelector("#inventory_filter_container > select")).click();
       driver.findElement(By.cssSelector("#inventory_filter_container > select > option:nth-child(1)")).click();
       generateScreenshots("C:\\Users\\basil.b\\OneDrive - HCL TECHNOLOGIES LIMITED\\Desktop\\Screenshots-SwagLabs\\Filter1.jpg"); //Replace with your path
       driver.findElement(By.cssSelector("#inventory_filter_container > select > option:nth-child(2)")).click();
       generateScreenshots("C:\\Users\\basil.b\\OneDrive - HCL TECHNOLOGIES LIMITED\\Desktop\\Screenshots-SwagLabs\\Filter2.jpg"); //Replace with your path
       driver.findElement(By.cssSelector("#inventory_filter_container > select > option:nth-child(3)")).click();
       generateScreenshots("C:\\Users\\basil.b\\OneDrive - HCL TECHNOLOGIES LIMITED\\Desktop\\Screenshots-SwagLabs\\Filter3.jpg"); //Replace with your path
       driver.findElement(By.cssSelector("#inventory_filter_container > select > option:nth-child(4)")).click();
       generateScreenshots("C:\\Users\\basil.b\\OneDrive - HCL TECHNOLOGIES LIMITED\\Desktop\\Screenshots-SwagLabs\\Filter4.jpg"); //Replace with your path
       //System.out.println("Yes filter option is working"+"\n");
   }

   public void AddingAndRemovingCart() throws IOException {
	   driver.findElement(By.cssSelector("#inventory_container > div > div:nth-child(1) > div.pricebar > button")).click();
       driver.findElement(By.cssSelector("#inventory_container > div > div:nth-child(2) > div.pricebar > button")).click();
       driver.findElement(By.cssSelector("#inventory_container > div > div:nth-child(3) > div.pricebar > button")).click();
       driver.findElement(By.cssSelector("#inventory_container > div > div:nth-child(4) > div.pricebar > button")).click();
       driver.findElement(By.cssSelector("#inventory_container > div > div:nth-child(5) > div.pricebar > button")).click();
       driver.findElement(By.cssSelector("#inventory_container > div > div:nth-child(6) > div.pricebar > button")).click();
       driver.findElement(By.cssSelector("#shopping_cart_container > a > svg > path")).click();
       driver.findElement(By.xpath("//*[@id=\"cart_contents_container\"]/div/div[1]/div[3]/div[2]/div[2]/button")).click();
       driver.findElement(By.xpath("//*[@id=\"cart_contents_container\"]/div/div[1]/div[4]/div[2]/div[2]/button")).click();
       driver.findElement(By.xpath("//*[@id=\"cart_contents_container\"]/div/div[1]/div[5]/div[2]/div[2]/button")).click();
       driver.findElement(By.xpath("//*[@id=\"cart_contents_container\"]/div/div[1]/div[6]/div[2]/div[2]/button")).click();
       driver.findElement(By.xpath("//*[@id=\"cart_contents_container\"]/div/div[1]/div[7]/div[2]/div[2]/button")).click();
       driver.findElement(By.xpath("//*[@id=\"cart_contents_container\"]/div/div[1]/div[8]/div[2]/div[2]/button")).click();
       generateScreenshots("C:\\Users\\basil.b\\OneDrive - HCL TECHNOLOGIES LIMITED\\Desktop\\Screenshots-SwagLabs\\EmptyCart.jpg"); //Replace with your path
       openMenu();
       driver.findElement(By.cssSelector("#inventory_sidebar_link")).click();
       //System.out.println("Yes things can be removed from cart"+"\n");
   }

   public void ErrorHanler1() throws IOException {
       driver.findElement(By.cssSelector("#shopping_cart_container > a > svg > path")).click();
       driver.findElement(By.xpath("//*[@id=\"cart_contents_container\"]/div/div[2]/a[2]")).click();           
       driver.findElement(By.xpath("//*[@id=\"checkout_info_container\"]/div/form/div[2]/input")).click(); 
       generateScreenshots("C:\\Users\\basil.b\\OneDrive - HCL TECHNOLOGIES LIMITED\\Desktop\\Screenshots-SwagLabs\\FirstName.jpg"); //Replace with your path
       
       String Expected = "Error: First Name is required";
       String Actual = driver.findElement(By.xpath("//*[@id=\"checkout_info_container\"]/div/form/h3")).getText();
       SoftAssert sa = new SoftAssert();
 	   sa.assertEquals(Actual, Expected);
       System.out.println("Soft assert test");
       System.out.println("Expected: "+Expected);
       System.out.println("Actual: "+Actual+"\n");
       sa.assertAll();
       driver.navigate().refresh();
   }


   	  public void ErrorHanler2(String FirstName) throws IOException {
	  driver.findElement(By.xpath("//*[@id=\"first-name\"]")).sendKeys(FirstName);
      driver.findElement(By.xpath("//*[@id=\"checkout_info_container\"]/div/form/div[2]/input")).click();
      generateScreenshots("C:\\Users\\basil.b\\OneDrive - HCL TECHNOLOGIES LIMITED\\Desktop\\Screenshots-SwagLabs\\LastName.jpg"); //Replace with your path
      
      String Expected1 = "Error: Last Name is required";
      String Actual1 = driver.findElement(By.xpath("//*[@id=\"checkout_info_container\"]/div/form/h3")).getText();
      SoftAssert sa1 = new SoftAssert();
	  	 sa1.assertEquals(Actual1, Expected1);
      System.out.println("Soft assert test");
      System.out.println("Expected: "+Expected1);
      System.out.println("Actual: "+Actual1+"\n");
      sa1.assertAll();
      driver.navigate().refresh();
	
}
	public void ErrorHanler3(String FirstName,String LastName) throws IOException {
		 driver.findElement(By.xpath("//*[@id=\"first-name\"]")).sendKeys(FirstName);
         driver.findElement(By.xpath("//*[@id=\"last-name\"]")).sendKeys(LastName);
         driver.findElement(By.xpath("//*[@id=\"checkout_info_container\"]/div/form/div[2]/input")).click(); 
         generateScreenshots("C:\\Users\\basil.b\\OneDrive - HCL TECHNOLOGIES LIMITED\\Desktop\\Screenshots-SwagLabs\\PostalCode.jpg"); //Replace with your path
         
         String Expected2 = "Error: Postal Code is required";
         String Actual2 = driver.findElement(By.xpath("//*[@id=\"checkout_info_container\"]/div/form/h3")).getText();
         SoftAssert sa2 = new SoftAssert();
   	  	 sa2.assertEquals(Actual2, Expected2);
         System.out.println("Soft assert test");
         System.out.println("Expected: "+Expected2);
         System.out.println("Actual: "+Actual2+"\n");
         sa2.assertAll();
         driver.navigate().refresh();
         openMenu();
         Allitems();		
	}


	public void ShoppingTime(String FirstName, String LastName, String PostalCode) throws IOException {
        driver.findElement(By.cssSelector("#inventory_container > div > div:nth-child(1) > div.pricebar > button")).click();
        driver.findElement(By.cssSelector("#inventory_container > div > div:nth-child(2) > div.pricebar > button")).click();
        driver.findElement(By.cssSelector("#inventory_container > div > div:nth-child(3) > div.pricebar > button")).click();
        driver.findElement(By.cssSelector("#inventory_container > div > div:nth-child(4) > div.pricebar > button")).click();
        driver.findElement(By.cssSelector("#inventory_container > div > div:nth-child(5) > div.pricebar > button")).click();
        driver.findElement(By.cssSelector("#inventory_container > div > div:nth-child(6) > div.pricebar > button")).click();
        driver.findElement(By.cssSelector("#shopping_cart_container > a > svg > path")).click();
        generateScreenshots("C:\\Users\\basil.b\\OneDrive - HCL TECHNOLOGIES LIMITED\\Desktop\\Screenshots-SwagLabs\\CartFull.jpg"); //Replace with your path
        driver.findElement(By.xpath("//*[@id=\"cart_contents_container\"]/div/div[2]/a[2]")).click();              
        driver.findElement(By.xpath("//*[@id=\"first-name\"]")).sendKeys(FirstName);
        driver.findElement(By.xpath("//*[@id=\"last-name\"]")).sendKeys(LastName);
        driver.findElement(By.xpath("//*[@id=\"postal-code\"]")).sendKeys(PostalCode);
        driver.findElement(By.xpath("//*[@id=\"checkout_info_container\"]/div/form/div[2]/input")).click();
        driver.findElement(By.xpath("//*[@id=\"checkout_summary_container\"]/div/div[2]/div[8]/a[2]")).click(); 
        generateScreenshots("C:\\Users\\basil.b\\OneDrive - HCL TECHNOLOGIES LIMITED\\Desktop\\Screenshots-SwagLabs\\ThankYouPage.jpg"); //Replace with your path
        
        String Expected3 = "THANK YOU FOR YOUR ORDER";
        String Actual3 = driver.findElement(By.xpath("//*[@id=\"checkout_complete_container\"]/h2")).getText();
        SoftAssert sa3 = new SoftAssert();
  	  	 sa3.assertEquals(Actual3, Expected3);
        System.out.println("Soft assert test");
        System.out.println("Expected: "+Expected3);
        System.out.println("Actual: "+Actual3+"\n");         
        driver.findElement(By.xpath("//*[@id=\"checkout_complete_container\"]/img")).isDisplayed();
        System.out.println("Yes, the pony logo is displaying."+"\n");
        sa3.assertAll();
        
        openMenu();
        Allitems();
        //System.out.println("Yes shopping completed"+"\n");
	}


	public void About() throws IOException {
		//openMenu();
	 driver.findElement(By.xpath("//*[@id=\"menu_button_container\"]/div/div[3]/div/button")).click();
   	 driver.findElement(By.cssSelector("#about_sidebar_link")).click();
   	 
		WebDriverWait wait = new WebDriverWait(driver, 70);
		WebElement popup = wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector("#onetrust-banner-sdk > div > div")));
		popup.click();
		driver.findElement(By.cssSelector("#onetrust-accept-btn-handler")).click();		
		
        String Expected = "Sauce Labs: Cross Browser Testing, Selenium Testing & Mobile Testing";
        String Actual = driver.getTitle();
        SoftAssert sa = new SoftAssert();
  	  	 sa.assertEquals(Actual, Expected);
        System.out.println("Soft assert test");
        System.out.println("Expected: "+Expected);
        System.out.println("Actual: "+Actual+"\n");         
        sa.assertAll();
		
        String Expected1 = "The world relies on your code. Test on thousands of different device, browser, and OS configurations�anywhere, any time.";
        String Actual1 = driver.findElement(By.xpath("//*[@id=\"__next\"]/div[2]/div[1]/div/div[1]/div[1]/div/div[3]/p")).getText();
        SoftAssert sa1 = new SoftAssert();
  	  	 sa1.assertEquals(Actual1, Expected1);
        System.out.println("Soft assert test");
        System.out.println("Expected: "+Expected1);
        System.out.println("Actual: "+Actual1+"\n");         
        driver.findElement(By.cssSelector("#__next > div.MuiBox-root.css-14ifkx6 > div.MuiContainer-root.MuiContainer-maxWidthLg.css-sv9kmg > div > div.MuiStack-root.css-mq2a14 > div.MuiStack-root.css-10ffvtp > div > svg")).isDisplayed();
        System.out.println("Yes, the logo is displaying."+"\n");
        sa.assertAll();
        generateScreenshots("C:\\Users\\basil.b\\OneDrive - HCL TECHNOLOGIES LIMITED\\Desktop\\Screenshots-SwagLabs\\About.jpg"); //Replace with your path
	}

	public void Hover() throws IOException {

		//driver.navigate().refresh();

		
   	 new Actions(driver).moveToElement(driver.findElement(By.cssSelector("#__next > header > div > div > div.MuiStack-root.css-19diydd > div.PrivateHiddenCss-root.PrivateHiddenCss-mdDown.css-9sga2b > div > div:nth-child(1) > div.MuiStack-root.css-ckbju8"))).perform();
   	 new Actions(driver).moveToElement(driver.findElement(By.cssSelector("#__next > header > div > div > div.MuiStack-root.css-19diydd > div.PrivateHiddenCss-root.PrivateHiddenCss-mdDown.css-9sga2b > div > div:nth-child(2) > div.MuiStack-root.css-ckbju8"))).perform();
   	 new Actions(driver).moveToElement(driver.findElement(By.cssSelector("#__next > header > div > div > div.MuiStack-root.css-19diydd > div.PrivateHiddenCss-root.PrivateHiddenCss-mdDown.css-9sga2b > div > div:nth-child(4) > div.MuiStack-root.css-ckbju8"))).perform();
   	 new Actions(driver).moveToElement(driver.findElement(By.cssSelector("#__next > header > div > div > div.MuiStack-root.css-19diydd > div.PrivateHiddenCss-root.PrivateHiddenCss-mdDown.css-9sga2b > div > div:nth-child(5) > div.MuiStack-root.css-ckbju8"))).perform();
      //driver.navigate().back();
      System.out.println("Success");
	}
	
	public void Hover2() throws IOException {
		driver.navigate().refresh();
	   	//driver.findElement(By.cssSelector("#onetrust-accept-btn-handler")).click();
	     new Actions(driver).moveToElement(driver.findElement(By.cssSelector("#__next > div.MuiBox-root.css-1fv62hk > div > div.MuiGrid-root.MuiGrid-container.css-os0hv9 > div:nth-child(1) > a > div"))).perform();
	     new Actions(driver).moveToElement(driver.findElement(By.cssSelector("#__next > div.MuiBox-root.css-1fv62hk > div > div.MuiGrid-root.MuiGrid-container.css-os0hv9 > div:nth-child(2) > a > div"))).perform();	     
	     new Actions(driver).moveToElement(driver.findElement(By.cssSelector("#__next > div.MuiBox-root.css-1fv62hk > div > div.MuiGrid-root.MuiGrid-container.css-os0hv9 > div:nth-child(3) > a > div"))).perform();
	     new Actions(driver).moveToElement(driver.findElement(By.cssSelector("#__next > div.MuiBox-root.css-1fv62hk > div > div.MuiGrid-root.MuiGrid-container.css-os0hv9 > div:nth-child(4) > a > div"))).perform();
	     new Actions(driver).moveToElement(driver.findElement(By.cssSelector("#__next > div.MuiBox-root.css-1fv62hk > div > div.MuiGrid-root.MuiGrid-container.css-os0hv9 > div:nth-child(5) > a > div"))).perform();
	     new Actions(driver).moveToElement(driver.findElement(By.cssSelector("#__next > div.MuiBox-root.css-1fv62hk > div > div.MuiGrid-root.MuiGrid-container.css-os0hv9 > div:nth-child(6) > a > div"))).perform();
	     new Actions(driver).moveToElement(driver.findElement(By.cssSelector("#__next > div.MuiBox-root.css-1fv62hk > div > div.MuiGrid-root.MuiGrid-container.css-os0hv9 > div:nth-child(7) > a > div"))).perform();	     
//	     driver.navigate().back();
}
	public void BHover() throws IOException {
		
		driver.navigate().to("https://saucelabs.com/");
		
	     new Actions(driver).moveToElement(driver.findElement(By.cssSelector("#__next > header > div > div > div.PrivateHiddenCss-root.PrivateHiddenCss-mdDown.css-9sga2b > div > div.MuiBox-root.css-1ay9vb9 > a > button"))).perform();
	     new Actions(driver).moveToElement(driver.findElement(By.cssSelector("#__next > header > div > div > div.PrivateHiddenCss-root.PrivateHiddenCss-mdDown.css-9sga2b > div > div.MuiBox-root.css-0 > a > button"))).perform();
	     new Actions(driver).moveToElement(driver.findElement(By.cssSelector("#__next > div.MuiBox-root.css-14ifkx6 > div.MuiContainer-root.MuiContainer-maxWidthLg.css-sv9kmg > div > div.MuiStack-root.css-mq2a14 > div.MuiStack-root.css-lu2zz1 > div > div.MuiStack-root.css-chbenk > div:nth-child(1) > a > button"))).perform();
	     new Actions(driver).moveToElement(driver.findElement(By.cssSelector("#__next > div.MuiBox-root.css-14ifkx6 > div.MuiContainer-root.MuiContainer-maxWidthLg.css-sv9kmg > div > div.MuiStack-root.css-mq2a14 > div.MuiStack-root.css-lu2zz1 > div > div.MuiStack-root.css-chbenk > div:nth-child(2) > a > button.MuiButtonBase-root.MuiButton-root.MuiButton-outlined.MuiButton-outlinedDark.MuiButton-sizeMedium.MuiButton-outlinedSizeMedium.MuiButton-disableElevation.MuiButton-root.MuiButton-outlined.MuiButton-outlinedDark.MuiButton-sizeMedium.MuiButton-outlinedSizeMedium.MuiButton-disableElevation.css-hy804n"))).perform();
	     new Actions(driver).moveToElement(driver.findElement(By.cssSelector("#__next > div.MuiBox-root.css-1fv62hk > div > div.MuiStack-root.css-cp6wtk > a > button"))).perform();
	     new Actions(driver).moveToElement(driver.findElement(By.cssSelector("#__next > div.MuiBox-root.css-i0wo7i > div.MuiContainer-root.MuiContainer-maxWidthLg.MuiContainer-disableGutters.css-p516jw > div > div > div > div.swiper-slide.swiper-slide-active > div > div > div > div.MuiStack-root.css-aq0jt7 > div.MuiBox-root.css-0 > a > button.MuiButtonBase-root.MuiButton-root.MuiButton-outlined.MuiButton-outlinedDark.MuiButton-sizeMedium.MuiButton-outlinedSizeMedium.MuiButton-disableElevation.MuiButton-root.MuiButton-outlined.MuiButton-outlinedDark.MuiButton-sizeMedium.MuiButton-outlinedSizeMedium.MuiButton-disableElevation.css-1tmiigx"))).perform();
	     new Actions(driver).moveToElement(driver.findElement(By.cssSelector("#__next > div.MuiBox-root.css-i0wo7i > div.MuiContainer-root.MuiContainer-maxWidthLg.MuiContainer-disableGutters.css-p516jw > div > div > div > div.swiper-slide.swiper-slide-active > div > div > div > div.MuiStack-root.css-aq0jt7 > div.MuiBox-root.css-0 > a > button.MuiButtonBase-root.MuiButton-root.MuiButton-outlined.MuiButton-outlinedDark.MuiButton-sizeMedium.MuiButton-outlinedSizeMedium.MuiButton-disableElevation.MuiButton-root.MuiButton-outlined.MuiButton-outlinedDark.MuiButton-sizeMedium.MuiButton-outlinedSizeMedium.MuiButton-disableElevation.css-1tmiigx"))).perform();
	     new Actions(driver).moveToElement(driver.findElement(By.cssSelector("#__next > div.MuiBox-root.css-1g3j8ey > div > div > div.MuiStack-root.css-sdb1sx > a:nth-child(1) > button"))).perform();
	     

	     //driver.navigate().back();
	}


	public void Products() {
		driver.navigate().to("https://saucelabs.com/");
		
		new Actions(driver).moveToElement(driver.findElement(By.cssSelector("#__next > header > div > div > div.MuiStack-root.css-19diydd > div.PrivateHiddenCss-root.PrivateHiddenCss-mdDown.css-9sga2b > div > div:nth-child(1) > div.MuiStack-root.css-ckbju8"))).perform();
		new Actions(driver).moveToElement(driver.findElement(By.cssSelector("#__next > header > div > div > div.MuiStack-root.css-19diydd > div.PrivateHiddenCss-root.PrivateHiddenCss-mdDown.css-9sga2b > div > div:nth-child(1) > div.dropdown.MuiBox-root.css-1wxxy3g > div > div > div.MuiBox-root.css-1doduzn > div:nth-child(1) > div.MuiBox-root.css-0 > div.MuiBox-root.css-11ze7cv > div > a > div > div > div > div.MuiBox-root.css-0 > span"))).perform();
		new Actions(driver).moveToElement(driver.findElement(By.cssSelector("#__next > header > div > div > div.MuiStack-root.css-19diydd > div.PrivateHiddenCss-root.PrivateHiddenCss-mdDown.css-9sga2b > div > div:nth-child(1) > div.dropdown.MuiBox-root.css-1wxxy3g > div > div > div.MuiBox-root.css-1doduzn > div:nth-child(1) > div.MuiBox-root.css-0 > div.MuiBox-root.css-1n2ole0 > div:nth-child(1) > a > div > div > div"))).perform();
		new Actions(driver).moveToElement(driver.findElement(By.cssSelector("#__next > header > div > div > div.MuiStack-root.css-19diydd > div.PrivateHiddenCss-root.PrivateHiddenCss-mdDown.css-9sga2b > div > div:nth-child(1) > div.dropdown.MuiBox-root.css-1wxxy3g > div > div > div.MuiBox-root.css-1doduzn > div:nth-child(1) > div.MuiBox-root.css-0 > div.MuiBox-root.css-1n2ole0 > div:nth-child(2) > a > div > div > div"))).perform();
		new Actions(driver).moveToElement(driver.findElement(By.cssSelector("#__next > header > div > div > div.MuiStack-root.css-19diydd > div.PrivateHiddenCss-root.PrivateHiddenCss-mdDown.css-9sga2b > div > div:nth-child(1) > div.dropdown.MuiBox-root.css-1wxxy3g > div > div > div.MuiBox-root.css-1doduzn > div:nth-child(1) > div.MuiBox-root.css-0 > div.MuiBox-root.css-1n2ole0 > div:nth-child(3) > a > div > div > div"))).perform();
		new Actions(driver).moveToElement(driver.findElement(By.cssSelector("#__next > header > div > div > div.MuiStack-root.css-19diydd > div.PrivateHiddenCss-root.PrivateHiddenCss-mdDown.css-9sga2b > div > div:nth-child(1) > div.dropdown.MuiBox-root.css-1wxxy3g > div > div > div.MuiBox-root.css-1doduzn > div:nth-child(1) > div.MuiBox-root.css-0 > div.MuiBox-root.css-1n2ole0 > div:nth-child(4) > a > div > div > div"))).perform();
		new Actions(driver).moveToElement(driver.findElement(By.cssSelector("#__next > header > div > div > div.MuiStack-root.css-19diydd > div.PrivateHiddenCss-root.PrivateHiddenCss-mdDown.css-9sga2b > div > div:nth-child(1) > div.dropdown.MuiBox-root.css-1wxxy3g > div > div > div.MuiBox-root.css-1doduzn > div:nth-child(1) > div.MuiBox-root.css-0 > div.MuiBox-root.css-1n2ole0 > div:nth-child(5) > a > div > div > div"))).perform();
		new Actions(driver).moveToElement(driver.findElement(By.cssSelector("#__next > header > div > div > div.MuiStack-root.css-19diydd > div.PrivateHiddenCss-root.PrivateHiddenCss-mdDown.css-9sga2b > div > div:nth-child(1) > div.dropdown.MuiBox-root.css-1wxxy3g > div > div > div.MuiBox-root.css-1doduzn > div:nth-child(1) > div.MuiBox-root.css-0 > div.MuiBox-root.css-1n2ole0 > div:nth-child(6) > a > div > div > div"))).perform();
		new Actions(driver).moveToElement(driver.findElement(By.cssSelector("#__next > header > div > div > div.MuiStack-root.css-19diydd > div.PrivateHiddenCss-root.PrivateHiddenCss-mdDown.css-9sga2b > div > div:nth-child(1) > div.dropdown.MuiBox-root.css-1wxxy3g > div > div > div.MuiBox-root.css-1doduzn > div:nth-child(1) > div.MuiBox-root.css-0 > div.MuiBox-root.css-1n2ole0 > div:nth-child(7) > a > div > div > div"))).perform();
		new Actions(driver).moveToElement(driver.findElement(By.cssSelector("#__next > header > div > div > div.MuiStack-root.css-19diydd > div.PrivateHiddenCss-root.PrivateHiddenCss-mdDown.css-9sga2b > div > div:nth-child(1) > div.dropdown.MuiBox-root.css-1wxxy3g > div > div > div.MuiBox-root.css-1doduzn > div:nth-child(2) > div.MuiBox-root.css-0 > div.MuiBox-root.css-1n2ole0 > div:nth-child(1) > a > div > div > div"))).perform();
		new Actions(driver).moveToElement(driver.findElement(By.cssSelector("#__next > header > div > div > div.MuiStack-root.css-19diydd > div.PrivateHiddenCss-root.PrivateHiddenCss-mdDown.css-9sga2b > div > div:nth-child(1) > div.dropdown.MuiBox-root.css-1wxxy3g > div > div > div.MuiBox-root.css-1doduzn > div:nth-child(2) > div.MuiBox-root.css-0 > div.MuiBox-root.css-1n2ole0 > div:nth-child(2) > a > div > div > div"))).perform();
		new Actions(driver).moveToElement(driver.findElement(By.cssSelector("#__next > header > div > div > div.MuiStack-root.css-19diydd > div.PrivateHiddenCss-root.PrivateHiddenCss-mdDown.css-9sga2b > div > div:nth-child(1) > div.dropdown.MuiBox-root.css-1wxxy3g > div > div > div.MuiBox-root.css-gk763f > div:nth-child(1) > div.MuiBox-root.css-0 > div.MuiBox-root.css-8atqhb > div:nth-child(1) > a > div > div > div"))).perform();
		new Actions(driver).moveToElement(driver.findElement(By.cssSelector("#__next > header > div > div > div.MuiStack-root.css-19diydd > div.PrivateHiddenCss-root.PrivateHiddenCss-mdDown.css-9sga2b > div > div:nth-child(1) > div.dropdown.MuiBox-root.css-1wxxy3g > div > div > div.MuiBox-root.css-gk763f > div:nth-child(1) > div.MuiBox-root.css-0 > div.MuiBox-root.css-8atqhb > div:nth-child(2) > a > div > div > div"))).perform();
		new Actions(driver).moveToElement(driver.findElement(By.cssSelector("#__next > header > div > div > div.MuiStack-root.css-19diydd > div.PrivateHiddenCss-root.PrivateHiddenCss-mdDown.css-9sga2b > div > div:nth-child(1) > div.dropdown.MuiBox-root.css-1wxxy3g > div > div > div.MuiBox-root.css-gk763f > div:nth-child(1) > div.MuiBox-root.css-0 > div.MuiBox-root.css-8atqhb > div:nth-child(3) > a > div > div > div"))).perform();
		new Actions(driver).moveToElement(driver.findElement(By.cssSelector("#__next > header > div > div > div.MuiStack-root.css-19diydd > div.PrivateHiddenCss-root.PrivateHiddenCss-mdDown.css-9sga2b > div > div:nth-child(1) > div.dropdown.MuiBox-root.css-1wxxy3g > div > div > div.MuiBox-root.css-gk763f > div:nth-child(2) > div.MuiBox-root.css-0 > div.MuiBox-root.css-8atqhb > div > a > div > div > div > div > span"))).perform();
		
		
		//driver.navigate().back();
	}


	public void Solutions() {
		
		new Actions(driver).moveToElement(driver.findElement(By.cssSelector("#__next > header > div > div > div.MuiStack-root.css-19diydd > div.PrivateHiddenCss-root.PrivateHiddenCss-mdDown.css-9sga2b > div > div:nth-child(2) > div.MuiStack-root.css-ckbju8"))).perform();
		new Actions(driver).moveToElement(driver.findElement(By.xpath("//*[@id=\"__next\"]/header/div/div/div[1]/div[2]/div/div[2]/div[2]/div/div/div[1]/div[1]/div[2]/div[2]/div[1]/a/div/div/div"))).perform();
		new Actions(driver).moveToElement(driver.findElement(By.xpath("//*[@id=\"__next\"]/header/div/div/div[1]/div[2]/div/div[2]/div[2]/div/div/div[1]/div[1]/div[2]/div[2]/div[2]/a/div/div/div/div[2]/span"))).perform();
		new Actions(driver).moveToElement(driver.findElement(By.xpath("//*[@id=\"__next\"]/header/div/div/div[1]/div[2]/div/div[2]/div[2]/div/div/div[1]/div[2]/div[2]/div[2]/div[1]/a/div/div/div/div[2]/span"))).perform();
		new Actions(driver).moveToElement(driver.findElement(By.xpath("//*[@id=\"__next\"]/header/div/div/div[1]/div[2]/div/div[2]/div[2]/div/div/div[1]/div[2]/div[2]/div[2]/div[6]/a/div/div/div/div[2]/span"))).perform();
		new Actions(driver).moveToElement(driver.findElement(By.xpath("//*[@id=\"__next\"]/header/div/div/div[1]/div[2]/div/div[2]/div[2]/div/div/div[1]/div[2]/div[2]/div[2]/div[2]/a/div/div/div"))).perform();
		new Actions(driver).moveToElement(driver.findElement(By.xpath("//*[@id=\"__next\"]/header/div/div/div[1]/div[2]/div/div[2]/div[2]/div/div/div[1]/div[2]/div[2]/div[2]/div[7]/a/div/div/div/div[2]"))).perform();
		new Actions(driver).moveToElement(driver.findElement(By.xpath("//*[@id=\"__next\"]/header/div/div/div[1]/div[2]/div/div[2]/div[2]/div/div/div[1]/div[2]/div[2]/div[2]/div[3]/a/div/div/div"))).perform();
		new Actions(driver).moveToElement(driver.findElement(By.xpath("//*[@id=\"__next\"]/header/div/div/div[1]/div[2]/div/div[2]/div[2]/div/div/div[1]/div[2]/div[2]/div[2]/div[8]/a/div/div/div/div[2]/span"))).perform();
		new Actions(driver).moveToElement(driver.findElement(By.xpath("//*[@id=\"__next\"]/header/div/div/div[1]/div[2]/div/div[2]/div[2]/div/div/div[1]/div[2]/div[2]/div[2]/div[4]/a/div/div/div/div[2]/span"))).perform();
		new Actions(driver).moveToElement(driver.findElement(By.xpath("//*[@id=\"__next\"]/header/div/div/div[1]/div[2]/div/div[2]/div[2]/div/div/div[1]/div[2]/div[2]/div[2]/div[9]/a/div/div/div/div[2]/span"))).perform();
		new Actions(driver).moveToElement(driver.findElement(By.xpath("//*[@id=\"__next\"]/header/div/div/div[1]/div[2]/div/div[2]/div[2]/div/div/div[1]/div[2]/div[2]/div[2]/div[5]/a/div/div/div/div[2]/span"))).perform();
		new Actions(driver).moveToElement(driver.findElement(By.xpath("//*[@id=\"__next\"]/header/div/div/div[1]/div[2]/div/div[2]/div[2]/div/div/div[1]/div[2]/div[2]/div[2]/div[10]/a/div"))).perform();
		new Actions(driver).moveToElement(driver.findElement(By.xpath("//*[@id=\"__next\"]/header/div/div/div[1]/div[2]/div/div[2]/div[2]/div/div/div[2]/div/div[2]/div[1]/div[1]/a/div/div/div/div[2]"))).perform();
		new Actions(driver).moveToElement(driver.findElement(By.xpath("//*[@id=\"__next\"]/header/div/div/div[1]/div[2]/div/div[2]/div[2]/div/div/div[2]/div/div[2]/div[1]/div[2]/a/div/div/div/div[2]/span"))).perform();
		new Actions(driver).moveToElement(driver.findElement(By.xpath("//*[@id=\"__next\"]/header/div/div/div[1]/div[2]/div/div[2]/div[2]/div/div/div[2]/div/div[2]/div[1]/div[3]/a/div/div/div/div[2]"))).perform();
		new Actions(driver).moveToElement(driver.findElement(By.xpath("//*[@id=\"__next\"]/header/div/div/div[1]/div[2]/div/div[2]/div[2]/div/div/div[2]/div/div[2]/div[1]/div[4]/a/div/div/div/div[2]/span"))).perform();
		new Actions(driver).moveToElement(driver.findElement(By.xpath("//*[@id=\"__next\"]/header/div/div/div[1]/div[2]/div/div[2]/div[2]/div/div/div[2]/div/div[2]/div[1]/div[5]/a/div/div/div/div[2]/span"))).perform();
		new Actions(driver).moveToElement(driver.findElement(By.xpath("//*[@id=\"__next\"]/header/div/div/div[1]/div[2]/div/div[2]/div[2]/div/div/div[2]/div/div[2]/div[1]/div[6]/a/div/div/div/div[2]"))).perform();
		
		//driver.navigate().back();
	}
	public void Developers() {
		
		new Actions(driver).moveToElement(driver.findElement(By.cssSelector("#__next > header > div > div > div.MuiStack-root.css-19diydd > div.PrivateHiddenCss-root.PrivateHiddenCss-mdDown.css-9sga2b > div > div:nth-child(4) > div.MuiStack-root.css-ckbju8"))).perform();
		new Actions(driver).moveToElement(driver.findElement(By.xpath("//*[@id=\"__next\"]/header/div/div/div[1]/div[2]/div/div[4]/div[2]/div/div/div[1]/div[1]/div[2]/div[2]/div[1]/a/div"))).perform();
		new Actions(driver).moveToElement(driver.findElement(By.xpath("//*[@id=\"__next\"]/header/div/div/div[1]/div[2]/div/div[4]/div[2]/div/div/div[1]/div[1]/div[2]/div[2]/div[3]/a/div/div[2]/span"))).perform();
		new Actions(driver).moveToElement(driver.findElement(By.xpath("//*[@id=\"__next\"]/header/div/div/div[1]/div[2]/div/div[4]/div[2]/div/div/div[1]/div[1]/div[2]/div[2]/div[2]/a/div/div[1]/div"))).perform();
		new Actions(driver).moveToElement(driver.findElement(By.xpath("//*[@id=\"__next\"]/header/div/div/div[1]/div[2]/div/div[4]/div[2]/div/div/div[1]/div[1]/div[2]/div[2]/div[4]/a/div"))).perform();
		new Actions(driver).moveToElement(driver.findElement(By.xpath("//*[@id=\"__next\"]/header/div/div/div[1]/div[2]/div/div[4]/div[2]/div/div/div[1]/div[2]/div[2]/div[2]/div[1]/a/div"))).perform();
		new Actions(driver).moveToElement(driver.findElement(By.xpath("//*[@id=\"__next\"]/header/div/div/div[1]/div[2]/div/div[4]/div[2]/div/div/div[1]/div[2]/div[2]/div[2]/div[3]/a/div/div/div/div/span"))).perform();
		new Actions(driver).moveToElement(driver.findElement(By.xpath("//*[@id=\"__next\"]/header/div/div/div[1]/div[2]/div/div[4]/div[2]/div/div/div[1]/div[2]/div[2]/div[2]/div[2]/a/div/div/div"))).perform();
		new Actions(driver).moveToElement(driver.findElement(By.xpath("//*[@id=\"__next\"]/header/div/div/div[1]/div[2]/div/div[4]/div[2]/div/div/div[1]/div[2]/div[2]/div[2]/div[4]/a/div/div/div"))).perform();
		new Actions(driver).moveToElement(driver.findElement(By.xpath("//*[@id=\"__next\"]/header/div/div/div[1]/div[2]/div/div[4]/div[2]/div/div/div[1]/div[3]/div[2]/div[2]/div[1]/a/div/div/div/div/span"))).perform();
		new Actions(driver).moveToElement(driver.findElement(By.xpath("//*[@id=\"__next\"]/header/div/div/div[1]/div[2]/div/div[4]/div[2]/div/div/div[1]/div[3]/div[2]/div[2]/div[3]/a/div/div/div/div/span"))).perform();
		new Actions(driver).moveToElement(driver.findElement(By.xpath("//*[@id=\"__next\"]/header/div/div/div[1]/div[2]/div/div[4]/div[2]/div/div/div[1]/div[3]/div[2]/div[2]/div[2]/a/div"))).perform();
		new Actions(driver).moveToElement(driver.findElement(By.xpath("//*[@id=\"__next\"]/header/div/div/div[1]/div[2]/div/div[4]/div[2]/div/div/div[1]/div[3]/div[2]/div[2]/div[4]/a/div/div/div"))).perform();
		new Actions(driver).moveToElement(driver.findElement(By.xpath("//*[@id=\"__next\"]/header/div/div/div[1]/div[2]/div/div[4]/div[2]/div/div/div[2]/div[1]/div[2]/div[1]/div[1]/a/div/div/div/div/span"))).perform();
		new Actions(driver).moveToElement(driver.findElement(By.xpath("//*[@id=\"__next\"]/header/div/div/div[1]/div[2]/div/div[4]/div[2]/div/div/div[2]/div[1]/div[2]/div[1]/div[2]/a/div/div/div/div/span"))).perform();
		new Actions(driver).moveToElement(driver.findElement(By.xpath("//*[@id=\"__next\"]/header/div/div/div[1]/div[2]/div/div[4]/div[2]/div/div/div[2]/div[1]/div[2]/div[1]/div[3]/a/div/div/div/div/span"))).perform();
		new Actions(driver).moveToElement(driver.findElement(By.xpath("//*[@id=\"__next\"]/header/div/div/div[1]/div[2]/div/div[4]/div[2]/div/div/div[2]/div[2]/div[2]/div[1]/div[1]/a/div/div/div/div/span"))).perform();
		new Actions(driver).moveToElement(driver.findElement(By.xpath("//*[@id=\"__next\"]/header/div/div/div[1]/div[2]/div/div[4]/div[2]/div/div/div[2]/div[2]/div[2]/div[1]/div[2]/a/div"))).perform();
		new Actions(driver).moveToElement(driver.findElement(By.xpath("//*[@id=\"__next\"]/header/div/div/div[1]/div[2]/div/div[4]/div[2]/div/div/div[2]/div[2]/div[2]/div[1]/div[3]/a/div/div/div/div/span"))).perform();
		new Actions(driver).moveToElement(driver.findElement(By.xpath("//*[@id=\"__next\"]/header/div/div/div[1]/div[2]/div/div[4]/div[2]/div/div/div[2]/div[2]/div[2]/div[1]/div[4]/a/div/div/div/div/span"))).perform();
		
		//driver.navigate().back();
	}
	public void Resources() {
		
		new Actions(driver).moveToElement(driver.findElement(By.cssSelector("#__next > header > div > div > div.MuiStack-root.css-19diydd > div.PrivateHiddenCss-root.PrivateHiddenCss-mdDown.css-9sga2b > div > div:nth-child(5) > div.MuiStack-root.css-ckbju8"))).perform();
		new Actions(driver).moveToElement(driver.findElement(By.xpath("//*[@id=\"__next\"]/header/div/div/div[1]/div[2]/div/div[5]/div[2]/div/div/div[1]/div/div[1]/div/div[2]/div[1]/div[1]/a/div/div[1]/div"))).perform();
		new Actions(driver).moveToElement(driver.findElement(By.xpath("//*[@id=\"__next\"]/header/div/div/div[1]/div[2]/div/div[5]/div[2]/div/div/div[1]/div/div[1]/div/div[2]/div[1]/div[2]/a/div/div[2]"))).perform();
		new Actions(driver).moveToElement(driver.findElement(By.xpath("//*[@id=\"__next\"]/header/div/div/div[1]/div[2]/div/div[5]/div[2]/div/div/div[1]/div/div[1]/div/div[2]/div[1]/div[3]/a/div/div[1]/div"))).perform();
		new Actions(driver).moveToElement(driver.findElement(By.xpath("//*[@id=\"__next\"]/header/div/div/div[1]/div[2]/div/div[5]/div[2]/div/div/div[1]/div/div[1]/div/div[2]/div[1]/div[4]/a/div/div[1]/div"))).perform();
		new Actions(driver).moveToElement(driver.findElement(By.xpath("//*[@id=\"__next\"]/header/div/div/div[1]/div[2]/div/div[5]/div[2]/div/div/div[1]/div/div[1]/div/div[2]/div[1]/div[5]/a/div"))).perform();
		new Actions(driver).moveToElement(driver.findElement(By.xpath("//*[@id=\"__next\"]/header/div/div/div[1]/div[2]/div/div[5]/div[2]/div/div/div[1]/div/div[2]/div/div[2]/div[1]/div[1]/a/div/div[1]/div"))).perform();
		new Actions(driver).moveToElement(driver.findElement(By.xpath("//*[@id=\"__next\"]/header/div/div/div[1]/div[2]/div/div[5]/div[2]/div/div/div[1]/div/div[2]/div/div[2]/div[1]/div[2]/a/div/div[1]/div"))).perform();
		new Actions(driver).moveToElement(driver.findElement(By.xpath("//*[@id=\"__next\"]/header/div/div/div[1]/div[2]/div/div[5]/div[2]/div/div/div[1]/div/div[2]/div/div[2]/div[1]/div[3]/a/div/div[2]"))).perform();
		new Actions(driver).moveToElement(driver.findElement(By.xpath("//*[@id=\"__next\"]/header/div/div/div[1]/div[2]/div/div[5]/div[2]/div/div/div[1]/div/div[3]/div/div[2]/div[1]/div/a/div/div/div/div/span"))).perform();
		new Actions(driver).moveToElement(driver.findElement(By.xpath("//*[@id=\"__next\"]/header/div/div/div[1]/div[2]/div/div[5]/div[2]/div/div/div[1]/div/div[3]/div/div[2]/div[2]/div[1]/a/div/div/div/div/span"))).perform();
		new Actions(driver).moveToElement(driver.findElement(By.xpath("//*[@id=\"__next\"]/header/div/div/div[1]/div[2]/div/div[5]/div[2]/div/div/div[1]/div/div[3]/div/div[2]/div[2]/div[2]/a/div/div/div/div/span"))).perform();
		new Actions(driver).moveToElement(driver.findElement(By.xpath("//*[@id=\"__next\"]/header/div/div/div[1]/div[2]/div/div[5]/div[2]/div/div/div[1]/div/div[3]/div/div[2]/div[2]/div[3]/a/div/div/div/div/span"))).perform();
		new Actions(driver).moveToElement(driver.findElement(By.xpath("//*[@id=\"__next\"]/header/div/div/div[1]/div[2]/div/div[5]/div[2]/div/div/div[1]/div/div[3]/div/div[2]/div[2]/div[4]/a/div/div/div/div/span"))).perform();
		new Actions(driver).moveToElement(driver.findElement(By.xpath("//*[@id=\"__next\"]/header/div/div/div[1]/div[2]/div/div[5]/div[2]/div/div/div[1]/div/div[3]/div/div[2]/div[2]/div[5]/a/div/div/div/div/span"))).perform();
		new Actions(driver).moveToElement(driver.findElement(By.xpath("//*[@id=\"__next\"]/header/div/div/div[1]/div[2]/div/div[5]/div[2]/div/div/div[1]/div/div[3]/div/div[2]/div[2]/div[5]/a/div/div/div/div/span"))).perform();
		new Actions(driver).moveToElement(driver.findElement(By.xpath("//*[@id=\"__next\"]/header/div/div/div[1]/div[2]/div/div[5]/div[2]/div/div/div[1]/div/div[3]/div/div[2]/div[2]/div[6]/a/div/div/div/div/span"))).perform();
		new Actions(driver).moveToElement(driver.findElement(By.xpath("//*[@id=\"__next\"]/header/div/div/div[1]/div[2]/div/div[5]/div[2]/div/div/div[1]/div/div[3]/div/div[2]/div[2]/div[7]/a/div/div/div"))).perform();
		new Actions(driver).moveToElement(driver.findElement(By.xpath("//*[@id=\"__next\"]/header/div/div/div[1]/div[2]/div/div[5]/div[2]/div/div/div[2]/div/div[2]/a[1]/div/div[1]/span/img"))).perform();
		new Actions(driver).moveToElement(driver.findElement(By.xpath("//*[@id=\"__next\"]/header/div/div/div[1]/div[2]/div/div[5]/div[2]/div/div/div[2]/div/div[2]/a[2]/div/div[1]/span/img"))).perform();
		
		driver.navigate().back();
	}
}