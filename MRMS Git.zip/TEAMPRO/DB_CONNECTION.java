package TEAMPRO;
import java.sql.Connection;
import java.sql.DriverManager;
public class DB_CONNECTION {
	public static Connection getConnection() throws Exception{
		String url="jdbc:oracle:thin:@localhost:1521:xe";
		String username="SAM";
		String password="SRI45333";
		Connection con= DriverManager.getConnection(url,username,password);
		return con;
	}}

//import java.sql.Connection;
//import java.sql.DriverManager;
//import java.sql.SQLException;
// 
//public class DB_CONNECTION {
// 
//    private static Connection connection;
// 
//    public static Connection getConnection() {
//        return connection;
//    }
// 
//    public static boolean connectToDatabase(String username, String password) {
//        try {
//            String url = "jdbc:oracle:thin:@localhost:1521:xe";
//            connection = DriverManager.getConnection(url, username, password);
//            return true;
//        } catch (SQLException e) {
//            e.printStackTrace();
//            return false;
//        }
//    }
// 
//    public static boolean isConnected() {
//        return connection != null;
//    }
//
//	
//}
// 